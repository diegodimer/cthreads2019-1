#include <cthread.h>
#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[])
{
    char string[1000];
    cidentify(string, 100);
    printf("%s\n", string);


}



